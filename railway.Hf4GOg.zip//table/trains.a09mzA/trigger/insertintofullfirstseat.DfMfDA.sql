create definer = root@localhost trigger InsertIntoFullFirstSeat
    after insert
    on trains
    for each row
BEGIN
	DECLARE d INT;
    DECLARE i INT;
    DECLARE st TIME;
    set d=0;
    set i=0;
	set st = new.start_t;
    WHILE d <= 7 DO
		
        IF (d=0 and TIME(NOW()) >st) or (d=7 and TIME(NOW()) <=st) or (d>0 and d<7) THEN
			IF (DAYNAME(DATE_ADD(CURDATE(), INTERVAL d DAY)) = "Sunday" ) and (new.sun = 1) THEN
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL d DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=1;
            while i<=17 do
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL (d+i*7) DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=i+1;
            end while;
            END IF;
            
            			IF (DAYNAME(DATE_ADD(CURDATE(), INTERVAL d DAY)) = "Monday" ) and (new.mon = 1) THEN
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL d DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=1;
            while i<=17 do
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL (d+i*7) DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=i+1;
            end while;
            END IF;
            
            			IF (DAYNAME(DATE_ADD(CURDATE(), INTERVAL d DAY)) = "Tuesday" ) and (new.tue = 1) THEN
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL d DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=1;
            while i<=17 do
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL (d+i*7) DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=i+1;
            end while;
            END IF;
            
            			IF (DAYNAME(DATE_ADD(CURDATE(), INTERVAL d DAY)) = "Wednesday" ) and (new.wed = 1) THEN
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL d DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=1;
            while i<=17 do
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL (d+i*7) DAY), DATETIME), st) , 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=i+1;
            end while;
            END IF;
            
            			IF (DAYNAME(DATE_ADD(CURDATE(), INTERVAL d DAY)) = "Thursday" ) and (new.thu = 1) THEN
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL d DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=1;
            while i<=17 do
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL (d+i*7) DAY), DATETIME), st) , 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=i+1;
            end while;
            END IF;
            
            
            			IF (DAYNAME(DATE_ADD(CURDATE(), INTERVAL d DAY)) = "Friday" ) and (new.fri = 1) THEN
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL d DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=1;
            while i<=17 do
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL (d+i*7) DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=i+1;
            end while;
            END IF;
            
            
            			IF (DAYNAME(DATE_ADD(CURDATE(), INTERVAL d DAY)) = "Saturday" ) and (new.sat = 1) THEN
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL d DAY), DATETIME), st), 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=1;
            while i<=17 do
            INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
            VALUES (NEW.id, ADDTIME(CONVERT(DATE_ADD(CURDATE(), INTERVAL (d+i*7) DAY), DATETIME), st) , 1,NEW.AC1,18,NEW.AC2,54, NEW.AC3, 72,NEW.S,80, NEW.G,90);
            set i=i+1;
            end while;
            END IF;
        END IF;
        SET d = d + 1;
    END WHILE;
END;

