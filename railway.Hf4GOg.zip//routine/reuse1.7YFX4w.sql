create
    definer = root@localhost procedure reuse1(IN departure_date datetime, IN station_code1 varchar(10),
                                              IN station_code2 varchar(10))
BEGIN
call before_search();
SET @s1 = station_code1;
SET @s2 = station_code2;
SET @lola = CONCAT('%', @s1,'%',@s2,'%');

SELECT train_id,MIN(start_time) AS start_time, class, COUNT(*) AS seat
FROM (
select * from reuse_seat as r
where r.train_id in (SELECT id from trains where path like @lola) and 
(ADDTIME(r.start_time , SUBSTRING_INDEX(SUBSTRING_INDEX(r.path, CONCAT(@s1,','), -1), ',', 1)) >= departure_date )and
 (ADDTIME(r.start_time , SUBSTRING_INDEX(SUBSTRING_INDEX(r.path, CONCAT(@s1,','), -1), ',', 1))<= ADDTIME(departure_date, "23:59:59"))
 )AS subquery_alias
GROUP BY train_id, class
ORDER BY train_id, class;

DEALLOCATE PREPARE dynamic_statement;
END;

