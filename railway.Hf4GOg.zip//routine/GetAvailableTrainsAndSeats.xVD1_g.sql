create
    definer = root@localhost procedure GetAvailableTrainsAndSeats(IN departure_date datetime,
                                                                  IN station_code1 varchar(10),
                                                                  IN station_code2 varchar(10))
BEGIN
call before_search();
SET @s1 = station_code1; -- The variable containing the column identifier (e.g., 'A')
SET @s2 = station_code2; -- Replace with the actual table name
SET @lola = CONCAT('%', @s1,'%',@s2,'%');

-- PREPARE dynamic_statement FROM @sql;
-- EXECUTE dynamic_statement;
select * from trains as t,full_first_seat as f
where t.id in (SELECT id from trains where path like @lola) and f.train_id in (SELECT id from trains where path like @lola) and t.id=f.train_id and 
(ADDTIME(f.start_time , SUBSTRING_INDEX(SUBSTRING_INDEX(t.path, CONCAT(@s1,','), -1), ',', 1)) >= departure_date )and
 (ADDTIME(f.start_time , SUBSTRING_INDEX(SUBSTRING_INDEX(t.path, CONCAT(@s1,','), -1), ',', 1))<= ADDTIME(departure_date, "23:59:59"));
DEALLOCATE PREPARE dynamic_statement;
END;

