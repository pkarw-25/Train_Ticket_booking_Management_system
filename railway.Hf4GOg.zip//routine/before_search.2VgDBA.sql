create
    definer = root@localhost procedure before_search()
BEGIN
	INSERT INTO full_first_seat (train_id, start_time, pnr, AC1,SAC1, AC2, SAC2, AC3, SAC3, S , SS , G , SG)
SELECT
    t.id,DATE_ADD(f.start_time, INTERVAL 7*18 DAY),1,t.AC1,18,t.AC2,54, t.AC3, 72,t.S,80, t.G,90
	FROM full_first_seat as f
    join trains as t on f.train_id=t.id
	WHERE f.start_time < NOW();

DELETE FROM full_first_seat
WHERE start_time < NOW();
END;

